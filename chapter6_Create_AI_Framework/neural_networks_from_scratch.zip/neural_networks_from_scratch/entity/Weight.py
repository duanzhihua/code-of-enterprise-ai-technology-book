class Weight:

	def __init__(self):
		return None
	
	#---------------------
	
	def get_weight_index(self):
		return self.__weight_index
	
	def set_weight_index(self, weight_index):
		self.__weight_index = weight_index
	
	def get_from_index(self):
		return self.__from_index
	
	def set_from_index(self, from_index):
		self.__from_index = from_index
	
	def get_to_index(self):
		return self.__to_index
	
	def set_to_index(self, to_index):
		self.__to_index = to_index
	
	def get_from_label(self):
		return self.__from_label
	
	def set_from_label(self, from_label):
		self.__from_label = from_label
	
	def get_to_label(self):
		return self.__to_label
	
	def set_to_label(self, to_label):
		self.__to_label = to_label
	
	def get_value(self):
		return self.__value
	
	def set_value(self, value):
		self.__value = value
	
	def get_capital_delta(self):
		return self.__capital_delta
	
	def set_capital_delta(self, capital_delta):
		self.__capital_delta = capital_delta
	
	def get_derivative(self):
		return self.__derivative
	
	def set_derivative(self, derivative):
		self.__derivative = derivative