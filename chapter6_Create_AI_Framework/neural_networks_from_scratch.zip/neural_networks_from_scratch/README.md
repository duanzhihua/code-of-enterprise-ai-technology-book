

# Configuration

Load historical data in the instances variable in the main file. For instance, the following variable states Exclusive OR (XOR) dataset. Last item of an instance states results whereas other items state input features.

```python
#x1, x2, result
instances = [
      [0, 0, 0]
      , [0, 1, 1]
      , [1, 0, 1]
      , [1, 1, 0]
   ] 
```

In other words, 4th item of instances, [1, 1, 0], means x1 = 1, x2 = 1 and result = 0

Moreover, you should tune the following hyper-parameters for different datasets.

```python
dump = True #print messages in the console

epoch = 10000 #learning time

activation_function = 'sigmoid'

learning_rate = 0.1

applyAdaptiveLearning = False

momentum = 0
```

